import { allReducers } from "../reducer"
import { createStore} from 'redux'

const store = createStore(allReducers,window.__REDUX__DEVTOOLS__EXTENSIONS__ &&
    window.__REDUX__DEVTOOLS__EXTENSION__());
export default store;

