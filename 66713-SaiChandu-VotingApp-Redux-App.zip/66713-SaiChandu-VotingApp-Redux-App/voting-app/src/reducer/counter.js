
  let initialState = {
    party1: 0,
    party2: 0,
    party3: 0
  };

  //console.log(initialState);
export const counterReducer = (state=initialState, action)=>{
    //console.log(state)

    switch(action.type){

        case 'PARTY1':
            return {...state, party1: state.party1+1}
        
        case 'PARTY2':
               
            return {...state, party2: state.party2+1}

        case 'PARTY3':
                  
            return {...state, party3: state.party3+1}
          
      
        default:
            return state
    }

}