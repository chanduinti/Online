import React from 'react';
import { useDispatch } from 'react-redux';
import { l1party1,l1party2,l1party3, l2party1,l2party2,l2party3, l3party1,l3party2,l3party3} from '../action/counter';
import VoteCounting from './VoteCounting';

const PollingStations = () => {
    const dispatcher = useDispatch()
    return (
        
    <div className="container">
      <div className="card bg-info">
      <h1 className="text-center">Online Voting App</h1>
      </div>

      <div className="row m-5">
            <div className="card col-4">
                <div className="card-header bg-primary text-center fw-bold">Polling Station 1</div>
                <div className="card-body">
                <div className="row">
                <div className="m-2">
        
                    <button onClick={()=>{dispatcher(l1party1())}} className="btn btn-success btn-sm">Vote for 1</button>
                    <button  onClick={()=>{dispatcher(l1party2())}} className="btn btn-success btn-sm m-2">Vote for 2</button>
                    <button  onClick={()=>{dispatcher(l1party3())}} className="btn btn-success btn-sm">Vote for 3</button>
                </div>
            </div>
                </div>
            </div>

            <div className="card col-4 ">
                <div className="card-header bg-primary text-center fw-bold">Polling Station 2</div>
                <div className="card-body">
                  
                <div className="row">
                <div className="m-2">
        
                    <button onClick={()=>{dispatcher(l2party1())}} className="btn btn-success btn-sm">Vote for 1</button>
                    <button  onClick={()=>{dispatcher(l2party2())}} className="btn btn-success btn-sm m-2">Vote for 2</button>
                    <button  onClick={()=>{dispatcher(l2party3())}} className="btn btn-success btn-sm">Vote for 3</button>
                </div>
            </div>
                </div>
            </div>

            <div className="card col-4">
                <div className="card-header bg-primary text-center fw-bold">Polling Station 3</div>
                <div className="card-body">
                <div className="row">
                <div className="m-2">
        
                    <button onClick={()=>{dispatcher(l3party1())}} className="btn btn-success btn-sm">Vote for 1</button>
                    <button  onClick={()=>{dispatcher(l3party2())}} className="btn btn-success btn-sm m-2">Vote for 2</button>
                    <button  onClick={()=>{dispatcher(l3party3())}} className="btn btn-success btn-sm">Vote for 3</button>
                </div>
            </div>
                </div>
            </div>
        </div>

      <hr/> 
      <VoteCounting/>
    </div>
    
    );
};

export default PollingStations;