let initialState = {
    party1: 0,
    party2: 0,
    party3: 0
  };

export const locationthreeReducer =(state=initialState, action)=>{

    switch(action.type){
        case 'l3PARTY1':
            return {...state, party1: state.party1+1}
        
        case 'l3PARTY2':
               
            return {...state, party2: state.party2+1}

        case 'l3PARTY3':
                  
            return {...state, party3: state.party3+1}
          
        default:
            return state
    }

}