export const Increment=()=>{
    return{
        type: 'INCREMENT'
    } 
}

export const l1party1=()=>{
    return{
        type: 'PARTY1'
    } 
}

export const l1party2=()=>{
    return{
        type: 'PARTY2'
    } 
}

export const l1party3=()=>{
    return{
        type: 'PARTY3'
    } 
}

export const l2party1=()=>{
    return{
        type: 'l2PARTY1'
    } 
}

export const l2party2=()=>{
    return{
        type: 'l2PARTY2'
    } 
}

export const l2party3=()=>{
    return{
        type: 'l2PARTY3'
    } 
}

export const l3party1=()=>{
    return{
        type: 'l3PARTY1'
    } 
}

export const l3party2=()=>{
    return{
        type: 'l3PARTY2'
    } 
}

export const l3party3=()=>{
    return{
        type: 'l3PARTY3'
    } 
}

