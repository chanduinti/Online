
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.css'

import PollingStations from './components/PollingStations';

function App() {
  return (
   <div>
        <PollingStations/>
   </div>
  );
}

export default App;
