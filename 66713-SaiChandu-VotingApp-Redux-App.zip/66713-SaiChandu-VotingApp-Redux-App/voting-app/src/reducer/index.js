
import { combineReducers } from "redux"
import { counterReducer } from "./counter"
import { locationtwoReducer } from "./location2"

import { locationthreeReducer } from "./location3"


export const allReducers = combineReducers({
    l1counter : counterReducer,
    l2counter : locationtwoReducer,
    l3counter : locationthreeReducer

})

